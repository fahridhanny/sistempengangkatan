<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="refresh" content="0;url=pages/index.html">
    <title>Pengangkatan Karyawan Kontrak</title>
    <script language="javascript">
        window.location.href = "pages/index.php"
    </script>
</head>
<body>
<a href="pages/index.php">Pengangkatan Karyawan Kontrak</a>
</body>
</html>
